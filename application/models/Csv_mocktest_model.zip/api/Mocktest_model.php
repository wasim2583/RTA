<?php
class Mocktest_model  extends CI_model
{
	
		
	public function fetch_mocktest($nr,$si){
		$data=$this->db->select('*')->from('da_mocktest_tbl')
							  ->join('da_mocktest_options_tbl','da_mocktest_tbl.question_id=da_mocktest_options_tbl.question_id')
							  ->limit($nr,$si)
		                      ->order_by('da_mocktest_tbl.question_id','desc')
							  ->get()->result_array();
				return $data;
							 
	}
	
	public function mocktest(){
		$url= base_url().'uploads/mocktest/';
		$data=$this->db->select('m.question_id,m.question,m.answer,m.related_img,mo.option1,mo.option2,mo.option3,mo.option4,mo.option5')->from('da_mocktest_tbl m')
							 ->join('da_mocktest_options_tbl mo','m.question_id=mo.question_id')
							 ->where('m.answer!=',0)
							 ->order_by('m.question_id','RANDOM')
							 ->limit(20)
							 ->get()->result();
	
							
							return $data;
	}
	
	
}